const express = require('express')
const app = express()
const port = 3000
// const BloomFilter = require('bloomfilter').BloomFilter;
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
app.use(express.json());

// Assuming the same filter parameters as the Go example
let primaryBloomFilter;
let secondaryBloomFilter;
let p;
let q;
let numWebsites;
let ptm;
let stm;
let reports;
app.get('/', (req,res) => {
  res.status(200).send({ message: 'Beep Boop server is running' });
})


function zipf(k, s, N) {
    let denominator = 0;
    for (let n = 1; n <= N; n++) {
        denominator += 1 / Math.pow(n, s);
    }
    return (1 / Math.pow(k, s)) / denominator;
}

function estimateUniqueWebsites(totalReports) {
    const r = 2; // common ratio
    let n = 0;   // number of unique websites
    let sum = 0; // sum of the series

    while (sum < totalReports) {
        sum += Math.pow(r, n);
        n++;
    }

    // Subtract 1 to get the number of unique websites
    return n - 1;
}

app.post('/init', async (req, res) => {
  const filterSize = req.body.filterSize;
  const hstsData = req.body.hstsData;
  const httpData = req.body.httpData;
  const numHashes = Math.floor((Math.ceil(filterSize / hstsData.length) * Math.log(2)));
  p = req.body.p;
  q = req.body.q;
  numWebsites = req.body.numWebsites
  reports = 0
  ptm = req.body.ptm;
  stm = req.body.stm;
  console.log(hstsData.length)
  primaryBloomFilter = new BloomFilter(filterSize, numHashes);
  secondaryBloomFilter = new BloomFilter(filterSize, numHashes);
  for (let element of hstsData) {
    console.log(element)
    await primaryBloomFilter.add(element, p, q);
  }
  for (let element of httpData) {
    console.log(element)
    await secondaryBloomFilter.add(element, p, q);
  }
  fs.writeFileSync('primaryBloomFilter.json', JSON.stringify(primaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v));
  fs.writeFileSync('secondaryBloomFilter.json', JSON.stringify(secondaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v));
  fs.writeFileSync('parameters.json', JSON.stringify({p:p,q:q,numWebsites:numWebsites,ptm:ptm,stm:stm}));
  res.status(200).send({ message: 'Bloom filters created and stored.' });
});

function convertBigIntObjToString(obj) {
  let newObj = {};
  for (let key in obj) {
    if (typeof obj[key] === 'bigint') {
      newObj[key] = obj[key].toString() + 'n'; // Convert BigInt to string
    } else {
      newObj[key] = obj[key];
    }
  }
  return newObj;
}

app.get('/primaryBloomFilter', (req, res) => {
  if (!primaryBloomFilter) {
    let buf = JSON.parse(fs.readFileSync('primaryBloomFilter.json', 'utf8'), (_, v) => typeof v === 'string' && v.endsWith('n') ? BigInt(v.slice(0, -1)) : v);
    primaryBloomFilter = new BloomFilter(buf.filterSize, buf.numHashes);
    primaryBloomFilter.data = buf.data;
    primaryBloomFilter.count = buf.count;
  }
  res.status(200).send({bloomFilter:JSON.stringify(primaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v)});
});


app.get('/secondaryBloomFilter', (req, res) => {
  if (!secondaryBloomFilter) {
    let buf = JSON.parse(fs.readFileSync('secondaryBloomFilter.json', 'utf8'), (_, v) => typeof v === 'string' && v.endsWith('n') ? BigInt(v.slice(0, -1)) : v);
    secondaryBloomFilter = new BloomFilter(buf.filterSize, buf.numHashes);
    secondaryBloomFilter.data = buf.data;
    secondaryBloomFilter.count = buf.count;// Convert BigInt in hash to string
  }
  res.status(200).send({bloomFilter:JSON.stringify(secondaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v)});
});
app.get('/parameters',(req,res) => {
  if (!p || !q || !numWebsites || !ptm || !stm){
    buf = JSON.parse(fs.readFileSync('parameters.json'));
    p = buf.p;
    q = buf.q;
    numWebsites = buf.numWebsites
    ptm = buf.ptm;
    stm = buf.stm;
  } else{
    numWebsites = Math.floor((estimateUniqueWebsites(primaryBloomFilter.count)+estimateUniqueWebsites(secondaryBloomFilter.count))/2)
  }
   res.status(200).send({ p: p,q:q,numWebsites:numWebsites,
                         primaryThresholdModifier:ptm,
                         secondaryThresholdModifier:stm });
})

// Custom middleware to check the origin of the request
const checkOrigin = (req, res, next) => {
  const origin = req.get('Origin');
  if (origin === 'https://report-server.obonk.repl.co') {
    return next(); // Proceed to the next middleware or route handler
  } else {
    return res.status(403).send({ message: 'Forbidden: Invalid origin' });
  }
};
// Ensure only the report sever is reporting to us through checkOrigin
app.post("/report", (req, res) => {
  const data = req.body;
  console.log("got report")
  if (!primaryBloomFilter) {
    let buf = JSON.parse(fs.readFileSync('primaryBloomFilter.json', 'utf8'), (_, v) => typeof v === 'string' && v.endsWith('n') ? BigInt(v.slice(0, -1)) : v);
    primaryBloomFilter = new BloomFilter(buf.filterSize, buf.numHashes);
    primaryBloomFilter.data = buf.data;
    primaryBloomFilter.count = buf.count;
  }
  if (!secondaryBloomFilter) {
    let buf = JSON.parse(fs.readFileSync('secondaryBloomFilter.json', 'utf8'), (_, v) => typeof v === 'string' && v.endsWith('n') ? BigInt(v.slice(0, -1)) : v);
    secondaryBloomFilter = new BloomFilter(buf.filterSize, buf.numHashes);
    secondaryBloomFilter.data = buf.data;
    secondaryBloomFilter.count = buf.count;// Convert BigInt in hash to string
  }
  if (Array.isArray(data)) {
    // Assuming the data is an array of report objects
    for (let item of data) {
      // Add to corresponding bloomfilters
      if (item.type==1){
        primaryBloomFilter.add(item.dom,p,q)
      }else if(item.type==2){
        secondaryBloomFilter.add(item.dom,p,q)
      }
      reports +=1
    }
    fs.writeFileSync('primaryBloomFilter.json', JSON.stringify(primaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v));
    fs.writeFileSync('secondaryBloomFilter.json', JSON.stringify(secondaryBloomFilter, (_, v) => typeof v === 'bigint' ? v.toString() + 'n' : v));
    res.status(200).send({ message: 'Queue data received successfully' });
  } else {
    res.status(400).send({ message: 'Invalid data format' });
  }
})

app.listen(port, () => {
  // Code.....
})

class MurmurHash3 {
    constructor() {
        this.seed1 = 0;
        this.seed2 = 12345678;  // An arbitrary number, can be changed
    }

    update(data) {
        this.data = data;
        return this;
    }

    digest() {
        let hash1,hash2,data;
        data = this._hashWithSeed(this.data, this.seed1);
        hash1 = data[0]
        //this.seed1 = data[1]
        data = this._hashWithSeed(this.data, this.seed2);
        hash2 = data[0]
        //this.seed2 = data[1]
        console.log("Hash1:", hash1, "Hash2:", hash2);
        return (BigInt(hash1) << 32n) | BigInt(hash2);
    }

    reset() {
        this.data = '';
    }

    _hashWithSeed(data, seed) {
        let h = seed;
        const c1 = 0xcc9e2d51;
        const c2 = 0x1b873593;
        const r1 = 15;
        const r2 = 13;
        const m = 5;
        const n = 0xe6546b64;

        for(let i = 0; i < data.length; i++) {
            let k = data.charCodeAt(i);
            k *= c1;
            k = (k << r1) | (k >>> (32 - r1));
            k *= c2;

            h ^= k;
            h = (h << r2) | (h >>> (32 - r2));
            h = h * m + n;
        }

        h ^= data.length;
        h ^= h >>> 16;
        h *= 0x85ebca6b;
        h ^= h >>> 13;
        h *= 0xc2b2ae35;
        h ^= h >>> 16;
        
        return [h & 0xffffffff,h];
    }
}


class BloomFilter {
  constructor(filterSize, numHashes) {
      this.data = Array(filterSize).fill(0);
      this.hash = new MurmurHash3();
      this.filterSize = filterSize;
      this.numHashes = numHashes;
      this.count = 0;
  }

  add(data, p, q) {
      let [lower, upper] = this.hashKernel(data);
      console.log(lower,upper)
      let adq = q * 4294967295.0;
      let adp = p * 4294967295.0;
      let newData = Array(this.filterSize).fill(0);

      for(let i = 0; i < this.numHashes; i++) {
          let trueBit = (lower+upper*i)%this.filterSize;
          newData[trueBit]++;
      }

      let falseBits = 0;
      for(let i = 0; i < this.filterSize; i++) {
          let r = Math.floor(Math.random()* 4294967295.0);
          if(newData[i] == 1) {
              if(r >= adq) {
                  newData[i] = 0;
              }
          } else {
              if(r < adp) {
                  newData[i] = 1;
                  falseBits++;
              }
          }

          this.data[i] += newData[i];
      }

      this.count++;

      return this;
  }

  test(data) {
      let [lower, upper] = this.hashKernel(data);
      let result = Array(this.numHashes).fill(0);
      for(let i = 0; i < this.numHashes; i++) {
          let trueBit = (lower+upper*i)%this.filterSize;
          result[i] = this.data[trueBit];
      }

      return Math.min(...result);
  }

  hashKernel(data) {
      let sum = this.hash.update(data).digest();
      this.hash.reset();
      let upper = Number(BigInt(sum) & 0xffffffffn);
      let lower = Number((BigInt(sum) >> 32n) & 0xffffffffn);

      return [upper, lower];
  }
}


// class BloomFilter {
//     constructor(filterSize, numHashes) {
//         this.data = Array(filterSize).fill(0);
//         this.hash = crypto.createHash('sha256');
//         this.filterSize = filterSize;
//         this.numHashes = numHashes;
//         this.count = 0;
//     }

//     hashKernel(data) {
//         const hash = crypto.createHash('sha256');
//         hash.update(data);
//         const sum = hash.digest().readBigUInt64BE();
//         const upper = Number(sum & BigInt(0xffffffff));
//         const lower = Number((sum >> BigInt(32)) & BigInt(0xffffffff));
//         return [upper, lower];
//     }

//     add(data, p, q) {
//         const [lower, upper] = this.hashKernel(data);
//         const adq = Math.floor(q * 4294967295.0);
//         const adp = Math.floor(p * 4294967295.0);
//         const newData = Array(this.filterSize).fill(0);
//         let falseBits = 0;

//         for (let i = 0; i < this.numHashes; i++) {
//             const trueBit = ((lower + upper * i) % this.filterSize);
//             newData[trueBit] += 1;
//         }

//         for (let i = 0; i < this.filterSize; i++) {
//             const r = Math.floor(Math.random() * 4294967295.0);
//             if (newData[i] === 1) {
//                 if (r >= adq) {
//                     newData[i] = 0;
//                 }
//             } else {
//                 if (r < adp) {
//                     newData[i] = 1;
//                     falseBits += 1;
//                 }
//             }
//             this.data[i] += newData[i];
//         }
//         this.count++;

//         return this;
//     }

//     test(data) {
//         const [lower, upper] = this.hashKernel(data);
//         const result = Array(this.numHashes).fill(0);
//         let min = 0;

//         for (let i = 0; i < this.numHashes; i++) {
//             const trueBit = ((lower + upper * i) % this.filterSize);
//             result[i] = this.data[trueBit];
//         }

//         for (let i = 0; i < result.length; i++) {
//             if (i === 0 || result[i] < min) {
//                 min = result[i];
//             }
//         }

//         return min;
//     }
// }
