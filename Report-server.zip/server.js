const express = require('express');
const axios = require('axios'); // Import axios to make HTTP requests
const app = express();
const port = 3000;
const path = require('path');

let queue = [];

// Middleware to parse the request body as JSON
app.use(express.json());

// Render message that server is up
app.get('/', (req, res) => {
  res.status(200).send({ message: 'Beep Boop server is running' });
});

// Report endpoint
app.post('/report', (req, res) => {
  console.log("got report")
  queue.push({ "dom": req.body.dom, "type": req.body.type });
  res.status(200).send({ message: 'Report added to the queue' });
});

// Function to send the queue to another server and empty it
const sendQueueToServer = () => {
  console.log(queue.length)
  if (queue.length > 0) {
    console.log(queue)
    const queueToSend = [...queue];
    queue = []; // Empty the queue after making a copy
    
    axios.post('https://costrictor-directory.obonk.repl.co/report', queueToSend)
      .then(response => {
        console.log('Queue sent successfully:', response.data);
      })
      .catch(error => {
        console.error('Error sending queue:', error);
        // If there was an error sending the queue, we should put the items back in the queue to try again later.
        queue = queueToSend.concat(queue);
      });
  }
};

// Send the queue to another server every hour (3600000 milliseconds)
setInterval(sendQueueToServer, 2 *60 * 60 * 1000);

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
